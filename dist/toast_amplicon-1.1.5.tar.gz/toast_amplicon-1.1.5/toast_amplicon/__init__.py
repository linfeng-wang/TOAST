"""
A standalone bacterial amplicon designing tool (Tuberculosis Optimized Amplicon Sequencing Tool)
"""

__version__ = '1.1.5'